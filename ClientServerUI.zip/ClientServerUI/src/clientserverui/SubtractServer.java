package clientserverui;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Prajna Prabhakara
 */
public class SubtractServer {

    public SubtractServer() {
    }
    public static void main(String[] args) throws IOException{
 ServerSocket subserversocket=new ServerSocket(1434);
Socket ss=subserversocket.accept();
 Scanner in=new Scanner(ss.getInputStream());
 System.out.println(ss.getInputStream());        
     int a=in.nextInt();
     int b=in.nextInt();
        int dif=a-b;
        PrintStream p=new PrintStream(ss.getOutputStream());
     //Send value of sum to client
     p.println(dif);

    }
}
