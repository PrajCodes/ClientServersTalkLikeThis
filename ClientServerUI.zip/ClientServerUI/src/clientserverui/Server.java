
package clientserverui;

/**
 *
 * @author Prajna Prabhakara
 */
import java.awt.Dimension;
import java.io.*;
import java.util.*;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
public class Server {
    public static void main(String[] args) throws IOException{
//UI Part of program to visualize what is happening in the background        
          UIManager.put("OptionPane.minimumSize",new Dimension(1200,800)); 
          ImageIcon intro=new ImageIcon(Server.class.getResource("/clientserverui/Intro.jpg"));
          JOptionPane.showMessageDialog(null, "Introduction","Introduction",JOptionPane.INFORMATION_MESSAGE, intro);
          ImageIcon maintoadd=new ImageIcon(Server.class.getResource("/clientserverui/addserver.jpg"));
          ImageIcon maintosub=new ImageIcon(Server.class.getResource("/clientserverui/subserver.jpg"));
          ImageIcon maintomul=new ImageIcon(Server.class.getResource("/clientserverui/mulserver.jpg"));
          ImageIcon maintodiv=new ImageIcon(Server.class.getResource("/clientserverui/divserver.jpg"));
          ImageIcon maintolog=new ImageIcon(Server.class.getResource("/clientserverui/logserver.jpg"));

          int a,b,c,result = 0;  

//ServerSocket to listen to client requests 
     ServerSocket mainserversocket=new ServerSocket(1432);   
//The accept function accepts incoming request to mainserversocket
     Socket ms=mainserversocket.accept();
//below line accepts number passed by user to client
     Scanner in=new Scanner(ms.getInputStream());
     a=in.nextInt();
     b=in.nextInt();
     c=in.nextInt();
     switch (c) {
            case 1:  JOptionPane.showMessageDialog(null, "Connecting to Add Server ","Main Server to Add Server ",JOptionPane.INFORMATION_MESSAGE, maintoadd);
                     Socket connectToAdd=new Socket("127.0.0.1",1433);
                     System.out.println("Connecting to add server at port 1433");
                     PrintStream pa1=new PrintStream(connectToAdd.getOutputStream());
                     pa1.println(a);
                     System.out.println(pa1);
                     PrintStream pb1=new PrintStream(connectToAdd.getOutputStream());
                     pb1.println(b);
                     //Recieve the result from Addserver
                     Scanner in1=new Scanner(connectToAdd.getInputStream());
                     result = in1.nextInt();
                     System.out.println(result);
                     break;
            case 2:  JOptionPane.showMessageDialog(null, "Connecting to Subtract Server ","Main Server to Subtract Server ",JOptionPane.INFORMATION_MESSAGE, maintosub);
                     Socket connectToSub=new Socket("127.0.0.1",1434);
                     System.out.println("Connecting to Subtract server at port 1434");
                     PrintStream pa2=new PrintStream(connectToSub.getOutputStream());
                     pa2.println(a);
                     System.out.println(pa2);
                     PrintStream pb2=new PrintStream(connectToSub.getOutputStream());
                     pb2.println(b);
                     //Recieve the result from Subtract Server
                     Scanner in2=new Scanner(connectToSub.getInputStream());
                     result = in2.nextInt();
                     System.out.println(result);
                     break;
            case 3:  JOptionPane.showMessageDialog(null, "Connecting to Multiply Server ","Main Server to Multiply Server ",JOptionPane.INFORMATION_MESSAGE, maintomul);
                     Socket connectToMul=new Socket("127.0.0.1",1435);
                     System.out.println("Connecting to Multiply server at port 1435");
                     PrintStream pa3=new PrintStream(connectToMul.getOutputStream());
                     pa3.println(a);
                     System.out.println(pa3);
                     PrintStream pb3=new PrintStream(connectToMul.getOutputStream());
                     pb3.println(b);
                     //Recieve the result from Multiply Server
                     Scanner in3=new Scanner(connectToMul.getInputStream());
                     result = in3.nextInt();
                     System.out.println(result);
                     break;
            case 4:  JOptionPane.showMessageDialog(null, "Connecting to Division Server ","Main Server to Division Server ",JOptionPane.INFORMATION_MESSAGE, maintodiv);
                     Socket connectToDiv=new Socket("127.0.0.1",1436);
                     System.out.println("Connecting to Division server at port 1436");
                     PrintStream pa4=new PrintStream(connectToDiv.getOutputStream());
                     pa4.println(a);
                     System.out.println(pa4);
                     PrintStream pb4=new PrintStream(connectToDiv.getOutputStream());
                     pb4.println(b);
                     //Recieve the result from Division Server
                     Scanner in4=new Scanner(connectToDiv.getInputStream());
                     result = in4.nextInt();
                     System.out.println(result);
                     break;
            case 6: 
            case 7:
            case 8:  JOptionPane.showMessageDialog(null, "Connecting to Logical Server ","Main Server to Logical Server ",JOptionPane.INFORMATION_MESSAGE, maintolog);
                     Socket connectToLog=new Socket("127.0.0.1",1437);
                     System.out.println("Connecting to Logical server at port 1437");
                     PrintStream pa6=new PrintStream(connectToLog.getOutputStream());
                     pa6.println(a);
                     System.out.println(pa6);
                     PrintStream pb6=new PrintStream(connectToLog.getOutputStream());
                     pb6.println(b);
                     PrintStream pc6=new PrintStream(connectToLog.getOutputStream());
                     pc6.println(c);
                     //Recieve the result from Logical Operation Server
                     Scanner in6=new Scanner(connectToLog.getInputStream());
                     result = in6.nextInt();
                     System.out.println(result);
                     break;
          
            default: System.out.println("No Operation Selected");
                     break;
        }
     PrintStream p=new PrintStream(ms.getOutputStream());
     //Send value of result to client
     p.println(result);
    }  
}
