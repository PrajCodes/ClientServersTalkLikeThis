/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientserverui;

import clientserverui.MultithreadedServer;
import java.io.IOException;

/**
 *
 * @author prajn
 */
public class ClientsMT {

public static void main(String [] agrs) throws IOException{
MultithreadedServer newServer = new MultithreadedServer(1562);
new Thread(newServer).start();
 
try {
    Thread.sleep(15 * 1000);
} catch (InterruptedException e) {
    e.printStackTrace();
}
System.out.println("Stopping newServer");
newServer.stop();
}
}    

