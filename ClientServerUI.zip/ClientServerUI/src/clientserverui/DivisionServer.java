package clientserverui;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Prajna Prabhakara
 */
public class DivisionServer {

    public DivisionServer() {
    }
    public static void main(String[] args) throws IOException{
 ServerSocket divserversocket=new ServerSocket(1436);
Socket ds=divserversocket.accept();
 Scanner in=new Scanner(ds.getInputStream());
 System.out.println(ds.getInputStream());        
     int a=in.nextInt();
     int b=in.nextInt();
        int div=a/b;
        PrintStream p=new PrintStream(ds.getOutputStream());
     //Send value of sum to client
     p.println(div);

    }
}