package clientserverui;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Prajna Prabhakara
 */
public class LogicalOperationServer {

    public LogicalOperationServer() {
    }
    public static void main(String[] args) throws IOException{
 ServerSocket logserversocket=new ServerSocket(1437);
Socket ls=logserversocket.accept();
 Scanner in=new Scanner(ls.getInputStream());
 System.out.println(ls.getInputStream());  
   int result=0;
     int a=in.nextInt();
     int b=in.nextInt();
     int c=in.nextInt();
     if(c==6){
      result= (a & b);
    }
     if(c==7){
      result= (a | b);
    }
      if(c==8){
      result= (a ^ b);
    }

        PrintStream p=new PrintStream(ls.getOutputStream());
     //Send value of sum to client
     p.println(result);

    }
}

//References: https://docs.oracle.com/javase/tutorial/networking/sockets/index.html
