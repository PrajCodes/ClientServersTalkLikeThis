package clientserverui;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Prajna Prabhakara
 */
public class AddServer {

    public AddServer() {
    }
    public static void main(String[] args) throws IOException{
 ServerSocket addserversocket=new ServerSocket(1433);
Socket as=addserversocket.accept();
Scanner in=new Scanner(as.getInputStream());
System.out.println(as.getInputStream());        
     int a=in.nextInt();
     int b=in.nextInt();
        int sum=a+b;
        PrintStream p=new PrintStream(as.getOutputStream());
     //Send value of sum to client
     p.println(sum);

    }
}
