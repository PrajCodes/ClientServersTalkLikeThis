package clientserverui;
import java.awt.Dimension;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.*;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;

/**
 * netid sh3274
 * @author Prajna Prabhakara
 */
public class Client{
 
    public Client() {
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        int x,y,z,result;
        Scanner in=new Scanner(System.in);
        
//A simple socket with a port number to connect to server
        Socket c=new Socket("127.0.0.1",1432);
 //UI Part of Program to take in input from Client 
UIManager.put("OptionPane.minimumSize",new Dimension(1000,800)); 
JTextField firstNumber = new JTextField();
JTextField secondNumber = new JTextField();
JTextField operation = new JTextField();
ImageIcon clientbackground=new ImageIcon(Server.class.getResource("/clientserverui/client.jpg"));
Object[] message = {
    clientbackground,
    "A Simple Socket is created at the client system (localhost) at port number 1432 to connect to Server \n\n ",
    "Enter an integer number :", firstNumber,
    "\n Enter another integer number: ", secondNumber,
    "\n Enter one operation that needs to be performed on the above entered integers \n 1: Addition \n 2: Subtraction \n 3: Multiplication \n 4: Division \n" 
        + "Logical Operations  \n 6: Binary AND \n 7: Bitwise OR \n 8: Bitwise XOR\n ",operation
};
JOptionPane.showMessageDialog(null,message,"Client Message",JOptionPane.OK_OPTION);  

        x=Integer.parseInt(firstNumber.getText());
        PrintStream px=new PrintStream(c.getOutputStream());            
        px.println(x);
        y=Integer.parseInt(secondNumber.getText());
        PrintStream py=new PrintStream(c.getOutputStream());        
        py.println(y);
        z=Integer.parseInt(operation.getText());
        PrintStream pz=new PrintStream(c.getOutputStream());           
        pz.println(z);     
 //Using this socket to accept Result from server
        Scanner in1=new Scanner(c.getInputStream());
        result = in1.nextInt();
        ImageIcon resultrecieved=new ImageIcon(Server.class.getResource("/clientserverui/result.jpg"));
        JOptionPane.showMessageDialog(null, "Recieved result from main server: "+ String.valueOf(result), "Result" ,JOptionPane.INFORMATION_MESSAGE, resultrecieved);
        System.out.println("Result recieved is "+result);     
    }
    
}
