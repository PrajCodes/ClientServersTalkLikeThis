package clientserverui;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Prajna Prabhakara
 */
public class MultiplyServer {

    public MultiplyServer() {
    }
    public static void main(String[] args) throws IOException{
 ServerSocket mulserversocket=new ServerSocket(1435);
Socket muls=mulserversocket.accept();
 Scanner in=new Scanner(muls.getInputStream());
 System.out.println(muls.getInputStream());        
     int a=in.nextInt();
     int b=in.nextInt();
        int mul=a*b;
        PrintStream p=new PrintStream(muls.getOutputStream());
     //Send value of sum to client
     p.println(mul);

    }
}
